import { ActiveSessions } from '@/components/ActiveSessions'

export default async function Dashboard() {
  return (
    <main>
      <ActiveSessions />
    </main>
  )
}