'use client'
import { useState, useCallback, useEffect } from 'react'
import { useInterval } from '@/hooks/useInterval'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

export function CardDemo() {
  return (
    <Card className="w-full max-w-sm">
      <CardHeader>
        <CardTitle>Login to your account</CardTitle>
        <CardDescription>
          Enter your email below to login to your account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form>
          
        </form>
      </CardContent>
      <CardFooter className="flex-col gap-2">
        
      </CardFooter>
    </Card>
  )
}


export function ActiveSessions() {
  const [value, setValue] = useState<number | null>(null)

  const fetchMetric = useCallback(async () => {
    const res = await fetch('/api/metrics?q=auth_active_sessions')
    const data = await res.json()
    setValue(data?.value ?? null)
  }, [])

  useEffect(() => {
    fetchMetric()
  }, [fetchMetric])

  useInterval(fetchMetric, 5000)

  const isLoading = value === null

  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Active sessions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-semibold tabular-nums">
            {isLoading ? '—' : value!.toLocaleString()}
          </p>
          <div className="mt-2">

          </div>
        </CardContent>
      </Card>
    </div>
  )
}